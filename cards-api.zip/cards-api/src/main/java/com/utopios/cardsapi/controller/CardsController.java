package com.utopios.cardsapi.controller;

import com.utopios.cardsapi.model.Card;
import com.utopios.cardsapi.model.CardBlockRequest;
import com.utopios.cardsapi.model.CardIssuanceRequest;
import com.utopios.cardsapi.model.CardLimitsPatch;
import com.utopios.cardsapi.model.CardUnblockRequest;
import com.utopios.cardsapi.service.CardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cards")
@RequiredArgsConstructor
@Tag(name = "CardsAPI", description = "Gestion des cartes bancaires UtopiosBank")
public class CardsController {

    private final CardService service;

    @GetMapping
    @Operation(summary = "Liste des cartes",
               description = "Liste toutes les cartes avec filtrage et pagination")
    public Map<String, Object> listCards(
            @RequestParam(required = false) String customerId,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "20") int limit,
            @RequestParam(defaultValue = "0") int offset) {

        List<Card> cards = service.listCards(customerId, status, limit, offset);

        Map<String, Object> response = new HashMap<>();
        response.put("cards", cards);
        response.put("_meta", Map.of(
            "mocked", false,
            "source", "cards-api backend",
            "timestamp", ZonedDateTime.now(ZoneOffset.UTC).toString(),
            "count", cards.size()
        ));
        return response;
    }

    @GetMapping("/{cardId}")
    @Operation(summary = "Détail d'une carte")
    public Map<String, Object> getCard(
            @PathVariable String cardId,
            @RequestParam(required = false, defaultValue = "false") boolean includeHistory) {

        Card card = service.getCard(cardId);

        Map<String, Object> response = new HashMap<>();
        response.put("card", card);
        if (includeHistory) {
            response.put("recentTransactions", List.of(
                Map.of("date", "2026-04-15", "amount", "-42.50", "merchant", "CARREFOUR PARIS"),
                Map.of("date", "2026-04-14", "amount", "-15.80", "merchant", "METRO RATP"),
                Map.of("date", "2026-04-12", "amount", "-89.90", "merchant", "FNAC PARIS")
            ));
        }
        response.put("_meta", Map.of(
            "mocked", false,
            "source", "cards-api backend"
        ));
        return response;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Émettre une nouvelle carte")
    public Map<String, Object> issueCard(@Valid @RequestBody CardIssuanceRequest request) {

        CardService.IssuanceResult result = service.issueCard(request);

        return Map.of(
            "requestId", result.requestId(),
            "newCardId", result.newCardId(),
            "estimatedDeliveryDate", result.estimatedDeliveryDate().toString(),
            "status", "PENDING",
            "_meta", Map.of(
                "mocked", false,
                "source", "cards-api backend",
                "notice", "Carte en cours de production - livraison sous 5 jours ouvrés"
            )
        );
    }

    @PostMapping("/{cardId}/block")
    @Operation(summary = "Bloquer la carte (perte / vol)")
    public Map<String, Object> blockCard(
            @PathVariable String cardId,
            @Valid @RequestBody CardBlockRequest request) {

        Card card = service.blockCard(cardId, request);

        return Map.of(
            "cardId", card.getCardId(),
            "status", card.getStatus(),
            "blockedAt", ZonedDateTime.now(ZoneOffset.UTC).toString(),
            "reason", request.getReason(),
            "notificationSent", Boolean.TRUE.equals(request.getNotifyBySms()),
            "_meta", Map.of(
                "mocked", false,
                "source", "cards-api backend"
            )
        );
    }

    @PostMapping("/{cardId}/unblock")
    @Operation(summary = "Débloquer la carte après vérification 2FA")
    public Map<String, Object> unblockCard(
            @PathVariable String cardId,
            @Valid @RequestBody CardUnblockRequest request) {

        Card card = service.unblockCard(cardId, request);

        return Map.of(
            "cardId", card.getCardId(),
            "status", card.getStatus(),
            "unblockedAt", ZonedDateTime.now(ZoneOffset.UTC).toString(),
            "verificationMethod", request.getVerificationMethod(),
            "_meta", Map.of(
                "mocked", false,
                "source", "cards-api backend"
            )
        );
    }

    @PatchMapping("/{cardId}/limits")
    @Operation(summary = "Modifier les plafonds (PATCH partiel)")
    public Map<String, Object> updateLimits(
            @PathVariable String cardId,
            @Valid @RequestBody CardLimitsPatch patch) {

        Card card = service.updateLimits(cardId, patch);

        Map<String, Object> updatedLimits = new HashMap<>();
        updatedLimits.put("monthly", card.getMonthlyLimit());
        updatedLimits.put("weekly", card.getWeeklyLimit());
        updatedLimits.put("perTransaction", card.getPerTransactionLimit());
        updatedLimits.put("contactless", card.getContactlessLimit());

        String effective = patch.getEffectiveDate() != null
            ? patch.getEffectiveDate()
            : LocalDate.now().toString();

        return Map.of(
            "cardId", card.getCardId(),
            "updatedLimits", updatedLimits,
            "effectiveDate", effective,
            "_meta", Map.of(
                "mocked", false,
                "source", "cards-api backend"
            )
        );
    }

    @ExceptionHandler(CardService.CardNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(CardService.CardNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(
            "error", "CARD_NOT_FOUND",
            "message", e.getMessage(),
            "timestamp", ZonedDateTime.now(ZoneOffset.UTC).toString()
        ));
    }

    @ExceptionHandler(CardService.CardAlreadyBlockedException.class)
    public ResponseEntity<Map<String, Object>> handleAlreadyBlocked(
            CardService.CardAlreadyBlockedException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
            "error", "CARD_ALREADY_BLOCKED",
            "message", e.getMessage(),
            "timestamp", ZonedDateTime.now(ZoneOffset.UTC).toString()
        ));
    }

    @ExceptionHandler(CardService.CardNotBlockedException.class)
    public ResponseEntity<Map<String, Object>> handleNotBlocked(
            CardService.CardNotBlockedException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
            "error", "CARD_NOT_BLOCKED",
            "message", e.getMessage(),
            "timestamp", ZonedDateTime.now(ZoneOffset.UTC).toString()
        ));
    }

    @ExceptionHandler(CardService.VerificationFailedException.class)
    public ResponseEntity<Map<String, Object>> handleVerification(
            CardService.VerificationFailedException e) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of(
            "error", "VERIFICATION_FAILED",
            "message", e.getMessage(),
            "timestamp", ZonedDateTime.now(ZoneOffset.UTC).toString()
        ));
    }
}
