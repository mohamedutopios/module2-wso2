package com.utopios.cardsapi.repository;

import com.utopios.cardsapi.model.Card;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Repository in-memory pour la démo.
 * En production, remplacer par JPA + PostgreSQL/MySQL.
 */
@Repository
public class CardRepository {

    private final Map<String, Card> cards = new ConcurrentHashMap<>();

    @PostConstruct
    public void initData() {
        addCard(Card.builder()
            .cardId("CARD-001")
            .customerId("CUST-001")
            .maskedNumber("4970 XXXX XXXX 1234")
            .holderName("MARIE DUPONT")
            .cardType("DEBIT_GOLD")
            .status("ACTIVE")
            .expiryDate("2028-03")
            .monthlyLimit(new BigDecimal("8000.00"))
            .weeklyLimit(new BigDecimal("2500.00"))
            .perTransactionLimit(new BigDecimal("1500.00"))
            .contactlessLimit(new BigDecimal("50.00"))
            .contactless(true)
            .build());

        addCard(Card.builder()
            .cardId("CARD-002")
            .customerId("CUST-001")
            .maskedNumber("4970 XXXX XXXX 5678")
            .holderName("MARIE DUPONT")
            .cardType("VIRTUAL")
            .status("ACTIVE")
            .expiryDate("2027-11")
            .monthlyLimit(new BigDecimal("2000.00"))
            .weeklyLimit(new BigDecimal("800.00"))
            .perTransactionLimit(new BigDecimal("500.00"))
            .contactlessLimit(BigDecimal.ZERO)
            .contactless(false)
            .build());

        addCard(Card.builder()
            .cardId("CARD-003")
            .customerId("CUST-002")
            .maskedNumber("5320 XXXX XXXX 9876")
            .holderName("JEAN MARTIN")
            .cardType("CREDIT_PLATINUM")
            .status("ACTIVE")
            .expiryDate("2029-06")
            .monthlyLimit(new BigDecimal("25000.00"))
            .weeklyLimit(new BigDecimal("10000.00"))
            .perTransactionLimit(new BigDecimal("5000.00"))
            .contactlessLimit(new BigDecimal("150.00"))
            .contactless(true)
            .build());

        addCard(Card.builder()
            .cardId("CARD-004")
            .customerId("CUST-003")
            .maskedNumber("4970 XXXX XXXX 2222")
            .holderName("SOPHIE BERNARD")
            .cardType("DEBIT_CLASSIC")
            .status("BLOCKED")
            .expiryDate("2026-12")
            .monthlyLimit(new BigDecimal("3000.00"))
            .weeklyLimit(new BigDecimal("1000.00"))
            .perTransactionLimit(new BigDecimal("800.00"))
            .contactlessLimit(new BigDecimal("30.00"))
            .contactless(true)
            .build());

        addCard(Card.builder()
            .cardId("CARD-005")
            .customerId("CUST-004")
            .maskedNumber("4970 XXXX XXXX 3333")
            .holderName("LUC PETIT")
            .cardType("DEBIT_GOLD")
            .status("EXPIRED")
            .expiryDate("2024-10")
            .monthlyLimit(new BigDecimal("5000.00"))
            .weeklyLimit(new BigDecimal("1800.00"))
            .perTransactionLimit(new BigDecimal("1200.00"))
            .contactlessLimit(new BigDecimal("50.00"))
            .contactless(true)
            .build());
    }

    private void addCard(Card card) {
        cards.put(card.getCardId(), card);
    }

    public List<Card> findAll(String customerId, String status, int limit, int offset) {
        return cards.values().stream()
            .filter(c -> customerId == null || c.getCustomerId().equals(customerId))
            .filter(c -> status == null || c.getStatus().equals(status))
            .sorted((a, b) -> a.getCardId().compareTo(b.getCardId()))
            .skip(offset)
            .limit(limit)
            .toList();
    }

    public Optional<Card> findById(String cardId) {
        return Optional.ofNullable(cards.get(cardId));
    }

    public Card save(Card card) {
        cards.put(card.getCardId(), card);
        return card;
    }

    public boolean exists(String cardId) {
        return cards.containsKey(cardId);
    }

    public int count() {
        return cards.size();
    }
}
