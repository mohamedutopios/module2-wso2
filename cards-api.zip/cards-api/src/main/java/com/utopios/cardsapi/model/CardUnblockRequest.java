package com.utopios.cardsapi.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Schema(description = "Demande de déblocage d'une carte après vérification")
public class CardUnblockRequest {

    @NotBlank
    @Pattern(regexp = "SMS_2FA|APP_2FA|CALL_CENTER_MANUAL|BRANCH_VISIT")
    @Schema(example = "SMS_2FA", required = true,
            allowableValues = {"SMS_2FA", "APP_2FA", "CALL_CENTER_MANUAL", "BRANCH_VISIT"})
    private String verificationMethod;

    @NotBlank
    @Schema(example = "123456", required = true)
    private String verificationToken;

    @Schema(example = "OP-007",
            description = "Obligatoire pour CALL_CENTER_MANUAL et BRANCH_VISIT")
    private String operatorId;
}
