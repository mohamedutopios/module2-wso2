package com.utopios.cardsapi.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Schema(description = "Demande d'émission d'une nouvelle carte bancaire")
public class CardIssuanceRequest {

    @NotBlank
    @Schema(example = "CUST-001", required = true)
    private String customerId;

    @NotBlank
    @Pattern(regexp = "DEBIT_CLASSIC|DEBIT_GOLD|CREDIT_PLATINUM|VIRTUAL")
    @Schema(example = "DEBIT_GOLD", required = true,
            allowableValues = {"DEBIT_CLASSIC", "DEBIT_GOLD", "CREDIT_PLATINUM", "VIRTUAL"})
    private String cardType;

    @DecimalMin("100")
    @DecimalMax("10000")
    @Schema(example = "5000", description = "Plafond mensuel souhaité en EUR")
    private BigDecimal desiredLimit;

    @NotNull
    @Valid
    private DeliveryAddress deliveryAddress;

    @Data
    @Schema(description = "Adresse de livraison de la carte")
    public static class DeliveryAddress {
        @NotBlank
        @Schema(example = "12 rue de la Paix")
        private String street;

        @NotBlank
        @Schema(example = "Paris")
        private String city;

        @NotBlank
        @Schema(example = "75002")
        private String postalCode;

        @Schema(example = "FR", defaultValue = "FR")
        private String country = "FR";
    }
}
