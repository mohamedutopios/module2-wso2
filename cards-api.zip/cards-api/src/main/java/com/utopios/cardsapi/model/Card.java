package com.utopios.cardsapi.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Carte bancaire UtopiosBank")
public class Card {

    @Schema(example = "CARD-001")
    private String cardId;

    @Schema(example = "CUST-001")
    private String customerId;

    @Schema(example = "4970 XXXX XXXX 1234")
    private String maskedNumber;

    @Schema(example = "MARIE DUPONT")
    private String holderName;

    @Schema(example = "DEBIT_GOLD", allowableValues = {"DEBIT_CLASSIC", "DEBIT_GOLD", "CREDIT_PLATINUM", "VIRTUAL"})
    private String cardType;

    @Schema(example = "ACTIVE", allowableValues = {"ACTIVE", "BLOCKED", "EXPIRED"})
    private String status;

    @Schema(example = "2028-03")
    private String expiryDate;

    @Schema(example = "8000.00")
    private BigDecimal monthlyLimit;

    @Schema(example = "2500.00")
    private BigDecimal weeklyLimit;

    @Schema(example = "1500.00")
    private BigDecimal perTransactionLimit;

    @Schema(example = "50.00")
    private BigDecimal contactlessLimit;

    @Schema(example = "true")
    private Boolean contactless;
}
