package com.utopios.cardsapi.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Schema(description = "Modification partielle des plafonds de la carte (PATCH)")
public class CardLimitsPatch {

    @DecimalMin("0")
    @DecimalMax("50000")
    @Schema(example = "10000", description = "Plafond mensuel total en EUR")
    private BigDecimal monthlyLimit;

    @DecimalMin("0")
    @DecimalMax("15000")
    @Schema(example = "3000", description = "Plafond hebdomadaire")
    private BigDecimal weeklyLimit;

    @DecimalMin("0")
    @DecimalMax("5000")
    @Schema(example = "1500", description = "Plafond par transaction")
    private BigDecimal perTransactionLimit;

    @DecimalMin("0")
    @DecimalMax("150")
    @Schema(example = "50", description = "Plafond sans contact")
    private BigDecimal contactlessLimit;

    @Schema(example = "2026-05-01", description = "Date de prise d'effet (défaut immédiat)")
    private String effectiveDate;
}
