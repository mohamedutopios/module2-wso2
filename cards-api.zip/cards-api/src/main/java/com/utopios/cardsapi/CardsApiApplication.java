package com.utopios.cardsapi;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(
        title = "CardsAPI",
        version = "1.0.0",
        description = "API de gestion des cartes bancaires UtopiosBank",
        contact = @Contact(name = "UtopiosBank API Team", email = "api-team@utopios.com"),
        license = @License(name = "Proprietary")
    )
)
public class CardsApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CardsApiApplication.class, args);
    }
}
