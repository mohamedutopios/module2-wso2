package com.utopios.cardsapi.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(description = "Demande de blocage d'une carte")
public class CardBlockRequest {

    @NotBlank
    @Pattern(regexp = "LOST|STOLEN|FRAUD_SUSPECTED|OTHER")
    @Schema(example = "LOST", required = true,
            allowableValues = {"LOST", "STOLEN", "FRAUD_SUSPECTED", "OTHER"})
    private String reason;

    @Size(max = 500)
    @Schema(example = "Perdue dans le métro")
    private String comment;

    @Schema(example = "true", defaultValue = "true")
    private Boolean notifyBySms = true;
}
