package com.utopios.cardsapi.service;

import com.utopios.cardsapi.model.Card;
import com.utopios.cardsapi.model.CardBlockRequest;
import com.utopios.cardsapi.model.CardIssuanceRequest;
import com.utopios.cardsapi.model.CardLimitsPatch;
import com.utopios.cardsapi.model.CardUnblockRequest;
import com.utopios.cardsapi.repository.CardRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class CardService {

    private final CardRepository repository;

    public List<Card> listCards(String customerId, String status, int limit, int offset) {
        log.info("Listing cards: customerId={}, status={}, limit={}, offset={}",
                 customerId, status, limit, offset);
        return repository.findAll(customerId, status, limit, offset);
    }

    public Card getCard(String cardId) {
        log.info("Getting card: cardId={}", cardId);
        return repository.findById(cardId)
            .orElseThrow(() -> new CardNotFoundException(cardId));
    }

    public IssuanceResult issueCard(CardIssuanceRequest request) {
        log.info("Issuing card for customer={}, type={}",
                 request.getCustomerId(), request.getCardType());

        String requestId = "REQ-" + System.currentTimeMillis();
        String newCardId = "CARD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        BigDecimal limit = request.getDesiredLimit() != null
            ? request.getDesiredLimit()
            : new BigDecimal("5000.00");

        Card newCard = Card.builder()
            .cardId(newCardId)
            .customerId(request.getCustomerId())
            .maskedNumber(generateMaskedNumber())
            .holderName("NEW CARDHOLDER")
            .cardType(request.getCardType())
            .status("ACTIVE")
            .expiryDate(LocalDate.now().plusYears(3).toString().substring(0, 7))
            .monthlyLimit(limit)
            .weeklyLimit(limit.divide(new BigDecimal("4"), 2, java.math.RoundingMode.HALF_UP))
            .perTransactionLimit(limit.divide(new BigDecimal("10"), 2, java.math.RoundingMode.HALF_UP))
            .contactlessLimit(new BigDecimal("50.00"))
            .contactless(true)
            .build();

        repository.save(newCard);

        LocalDate estimatedDelivery = LocalDate.now().plusDays(5);
        log.info("Card issued: cardId={}, requestId={}", newCardId, requestId);

        return new IssuanceResult(requestId, newCardId, estimatedDelivery);
    }

    public Card blockCard(String cardId, CardBlockRequest request) {
        log.info("Blocking card: cardId={}, reason={}", cardId, request.getReason());

        Card card = getCard(cardId);

        if ("BLOCKED".equals(card.getStatus())) {
            throw new CardAlreadyBlockedException(cardId);
        }

        card.setStatus("BLOCKED");
        return repository.save(card);
    }

    public Card unblockCard(String cardId, CardUnblockRequest request) {
        log.info("Unblocking card: cardId={}, method={}",
                 cardId, request.getVerificationMethod());

        Card card = getCard(cardId);

        if (!"BLOCKED".equals(card.getStatus())) {
            throw new CardNotBlockedException(cardId);
        }

        if (!isValidVerification(request)) {
            throw new VerificationFailedException();
        }

        card.setStatus("ACTIVE");
        return repository.save(card);
    }

    public Card updateLimits(String cardId, CardLimitsPatch patch) {
        log.info("Updating limits: cardId={}", cardId);

        Card card = getCard(cardId);

        if (patch.getMonthlyLimit() != null) {
            card.setMonthlyLimit(patch.getMonthlyLimit());
        }
        if (patch.getWeeklyLimit() != null) {
            card.setWeeklyLimit(patch.getWeeklyLimit());
        }
        if (patch.getPerTransactionLimit() != null) {
            card.setPerTransactionLimit(patch.getPerTransactionLimit());
        }
        if (patch.getContactlessLimit() != null) {
            card.setContactlessLimit(patch.getContactlessLimit());
        }

        return repository.save(card);
    }

    private String generateMaskedNumber() {
        int last4 = (int) (Math.random() * 9000) + 1000;
        return "4970 XXXX XXXX " + last4;
    }

    private boolean isValidVerification(CardUnblockRequest request) {
        if (request.getVerificationToken() == null || request.getVerificationToken().isBlank()) {
            return false;
        }

        String method = request.getVerificationMethod();
        if ("CALL_CENTER_MANUAL".equals(method) || "BRANCH_VISIT".equals(method)) {
            return request.getOperatorId() != null && !request.getOperatorId().isBlank();
        }

        return true;
    }

    public record IssuanceResult(String requestId, String newCardId, LocalDate estimatedDeliveryDate) {}

    public static class CardNotFoundException extends RuntimeException {
        public CardNotFoundException(String cardId) {
            super("Card not found: " + cardId);
        }
    }

    public static class CardAlreadyBlockedException extends RuntimeException {
        public CardAlreadyBlockedException(String cardId) {
            super("Card already blocked: " + cardId);
        }
    }

    public static class CardNotBlockedException extends RuntimeException {
        public CardNotBlockedException(String cardId) {
            super("Card is not in BLOCKED state: " + cardId);
        }
    }

    public static class VerificationFailedException extends RuntimeException {
        public VerificationFailedException() {
            super("Verification failed: invalid token or missing operator ID");
        }
    }
}
