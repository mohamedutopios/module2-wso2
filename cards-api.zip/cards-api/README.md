# CardsAPI Backend

Backend Spring Boot pour la démo Design-first WSO2 APIM — gestion des cartes bancaires UtopiosBank.

## Stack technique

- **Spring Boot 3.2** (Web, Validation, Actuator)
- **Java 17**
- **springdoc-openapi** (Swagger UI)
- **Lombok**
- Stockage in-memory (pour démo ; remplaçable par JPA + DB)

## Endpoints exposés

Base URL : `http://localhost:8080`

| Méthode | URI | Description |
|---------|-----|-------------|
| GET | `/cards` | Liste des cartes (filtres : customerId, status, limit, offset) |
| GET | `/cards/{cardId}` | Détail d'une carte (param : includeHistory) |
| POST | `/cards` | Émission d'une nouvelle carte |
| POST | `/cards/{cardId}/block` | Blocage (perte/vol) |
| POST | `/cards/{cardId}/unblock` | Déblocage après 2FA |
| PATCH | `/cards/{cardId}/limits` | Modification partielle des plafonds |

Endpoints techniques :
- `GET /actuator/health` — health check
- `GET /actuator/info` — infos app
- `GET /actuator/metrics` — metrics
- `GET /actuator/prometheus` — format Prometheus
- `GET /swagger-ui.html` — Swagger UI
- `GET /v3/api-docs` — spec OpenAPI JSON

## Données initiales

Le backend démarre avec 5 cartes pré-chargées :

| cardId | holderName | cardType | status |
|--------|-----------|----------|--------|
| CARD-001 | MARIE DUPONT | DEBIT_GOLD | ACTIVE |
| CARD-002 | MARIE DUPONT | VIRTUAL | ACTIVE |
| CARD-003 | JEAN MARTIN | CREDIT_PLATINUM | ACTIVE |
| CARD-004 | SOPHIE BERNARD | DEBIT_CLASSIC | BLOCKED |
| CARD-005 | LUC PETIT | DEBIT_GOLD | EXPIRED |

## Lancement standalone

### Build + run local (hors Docker)

```bash
mvn clean package -DskipTests
java -jar target/cards-api.jar
```

### Build Docker

```bash
docker build -t cards-api:1.0.0 .
docker run -p 8088:8080 --name cards-api cards-api:1.0.0
```

### Dans la stack docker-compose de la démo 2

Le service est défini dans `docker-compose.yml` :

```yaml
cards-api:
  build: ./cards-api
  container_name: cards-api
  ports:
    - "8088:8080"
  networks:
    - utopios-net
  healthcheck:
    test: ["CMD-SHELL", "wget -q --spider http://localhost:8080/actuator/health || exit 1"]
    interval: 30s
    timeout: 5s
    start_period: 60s
    retries: 3
```

Démarrer via :
```bash
bash start.sh
```

## Tests

### Health check
```bash
curl http://localhost:8088/actuator/health | jq .
```

### Liste des cartes
```bash
curl http://localhost:8088/cards | jq .
```

### Filtrage
```bash
# Par statut
curl "http://localhost:8088/cards?status=ACTIVE" | jq .

# Par client
curl "http://localhost:8088/cards?customerId=CUST-001" | jq .

# Combiné avec pagination
curl "http://localhost:8088/cards?status=ACTIVE&limit=2&offset=0" | jq .
```

### Détail
```bash
# Simple
curl http://localhost:8088/cards/CARD-001 | jq .

# Avec historique de transactions
curl "http://localhost:8088/cards/CARD-001?includeHistory=true" | jq .
```

### Création
```bash
curl -X POST http://localhost:8088/cards \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "CUST-001",
    "cardType": "DEBIT_GOLD",
    "desiredLimit": 5000,
    "deliveryAddress": {
      "street": "12 rue de la Paix",
      "city": "Paris",
      "postalCode": "75002",
      "country": "FR"
    }
  }' | jq .
```

### Blocage
```bash
curl -X POST http://localhost:8088/cards/CARD-001/block \
  -H "Content-Type: application/json" \
  -d '{
    "reason": "LOST",
    "comment": "Perdue dans le métro",
    "notifyBySms": true
  }' | jq .
```

### Déblocage
```bash
curl -X POST http://localhost:8088/cards/CARD-001/unblock \
  -H "Content-Type: application/json" \
  -d '{
    "verificationMethod": "SMS_2FA",
    "verificationToken": "123456"
  }' | jq .
```

### Modification plafonds (PATCH partiel)
```bash
curl -X PATCH http://localhost:8088/cards/CARD-001/limits \
  -H "Content-Type: application/json" \
  -d '{
    "monthlyLimit": 12000,
    "contactlessLimit": 75
  }' | jq .
```

## Tests d'erreurs

### 404 — carte inexistante
```bash
curl -i http://localhost:8088/cards/CARD-INCONNU
# HTTP/1.1 404 Not Found
# {"error":"CARD_NOT_FOUND","message":"Card not found: CARD-INCONNU"}
```

### 409 — carte déjà bloquée
```bash
# CARD-004 est déjà BLOCKED au démarrage
curl -i -X POST http://localhost:8088/cards/CARD-004/block \
  -H "Content-Type: application/json" \
  -d '{"reason":"LOST"}'
# HTTP/1.1 409 Conflict
# {"error":"CARD_ALREADY_BLOCKED",...}
```

### 403 — token de vérification invalide
```bash
curl -i -X POST http://localhost:8088/cards/CARD-004/unblock \
  -H "Content-Type: application/json" \
  -d '{"verificationMethod":"SMS_2FA","verificationToken":""}'
# HTTP/1.1 400 (validation échoue sur @NotBlank)
```

## Intégration WSO2 APIM

Une fois le backend déployé dans la stack :

1. Publisher → CardsAPI → **Develop → Endpoints**
2. Supprimer le Mock Implementation
3. Ajouter un **HTTP/REST Endpoint** :
   - URL : `http://cards-api:8080`
4. **Save**
5. **Deploy → Deployments → Deploy New Revision**
6. Les consommateurs (FintechPartnerApp) appellent toujours :
   ```
   https://localhost:8243/cards/1.0.0/cards
   ```
   Mais ils obtiennent maintenant les vraies données du backend, pas le mock.

## Différence Mock / Backend

| Champ `_meta` | Mock | Backend |
|---------------|------|---------|
| `mocked` | `true` | `false` |
| `source` | absent | `"cards-api backend"` |
| `timestamp` | statique | temps réel UTC |
| Persistance | aucune | in-memory (redémarrage = reset) |
| Validation | souple | stricte (Jakarta Validation) |

## Customisation pour production

Pour passer en production, remplacer :
- `ConcurrentHashMap` → JPA + PostgreSQL/MySQL
- Données initiales `@PostConstruct` → Flyway/Liquibase migrations
- Exceptions RuntimeException → ProblemDetail (RFC 7807)
- Logs INFO → distributed tracing (OpenTelemetry)
- Pas d'auth → Spring Security + OAuth2 Resource Server
